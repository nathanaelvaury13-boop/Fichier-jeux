// serveur.js
const net = require('net');
const { exec } = require('child_process');

const PORT = 3000;

const serveur = net.createServer((socket) => {
    console.log(`[CONNEXION] Client connect� : ${socket.remoteAddress}`);

    socket.on('data', (data) => {
        const commande = data.toString().trim();
        console.log(`[RE�U] Commande re�ue : ${commande}`);

        if (commande === 'whoami' || commande === 'uptime') {
            exec(commande, (erreur, stdout) => {
                if (erreur) {
                    socket.write(`Erreur : ${erreur.message}`);
                } else {
                    socket.write(stdout);
                }
            });
        } else {
            socket.write("Commande refus�e.\n");
        }
    });

    socket.on('end', () => {
        console.log("[D�CONNEXION] Le client s'est d�connect�.");
    });
});

// �coute sur toutes les interfaces r�seau (Wi-Fi, Ethernet) sur le port 3000
serveur.listen(PORT, '0.0.0.0', () => {
    console.log(`[D�MARRAGE] Serveur d'�coute actif sur le port ${PORT}`);
});
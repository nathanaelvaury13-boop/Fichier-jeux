Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "lancer_tout.bat", 0, False